#pragma once
#include<iostream>
using namespace std;
class MyChar
{
private:
	char ch;

public:
	//parameterized constructor
	MyChar(char c = 0);

	//setters
	void setMyChar(char c);

	//getters
	char getMyChar();

	//MyFunctions
	char upper(char c);
	char lower(char c);
};

