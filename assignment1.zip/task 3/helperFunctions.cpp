#include"helperFunctions.h"
int strLength(char* p)
{
	int l = 0;
	for (int i = 0; p[i] != '\0'; i++)
	{
		l++;
	}
	return l;
}