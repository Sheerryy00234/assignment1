#include<iostream>
using namespace std;
int strLength(char*);

