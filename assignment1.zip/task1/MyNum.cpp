#include "MyNum.h"

//parameterized constructor
MyNum::MyNum(int n)
{
	num = n;
}

//setters
void MyNum::setMyNum(int n)
{
	num = n;
}

//getters
int MyNum::getMyNum()
{
	return num;
}

//My Functions
int MyNum::positive(int n)
{
	if (num < 0)
		return -n;
	else
		return n;
}
int MyNum::negative(int n)
{
	if (num > 0)
		return -n;
	else
		return n;
}