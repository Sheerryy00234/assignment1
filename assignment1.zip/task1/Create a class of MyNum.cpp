/*
Define a class MyNum having the following private attributes.
� A single integer variable.
Now do the following operations on above-mentioned class MyNum:
� Write parameterized constructor with default arguments.
� Write separate setters for each attribute to set value.
� Write separate getters for each attribute to get value.
� A function that can convert the number stored in MyNum into positiveNumber.
� A function that can convert the number stored in MyNum into negativeNumber.
Now write a driver program (main()) to test the following functionalities on
MyNum class on your own.
� Make a single MyNum object by taking data from user.
� Print a single MyNum object data on screen.
� Make N MyNum objects by taking data from the user, where N is asked from the user.
� Print N MyNum objects data on screen.
� Sort the N MyNum objects by values.
� Print the Sorted MyNum objects on screen.
*/

#include "MyNum.h"
int main()
{
	MyNum one;
	int num = 0;

	//cout << one.getMyNum() << endl;
	//cout << "Enter a number: "; cin >> num;

	//one.setMyNum(num);
	
	//cout << one.getMyNum() << endl;
	cout << "How many objects do you want to create." << endl;
	cout << "Enter here: "; cin >> num;

	MyNum *two = new MyNum[num];

	int size = num;

	cout << "Enter data for MyNum objects." << endl;
	for (int i = 0; i < size; i++)
	{
		cout << "Enter number for object " << i << ": "; cin >> num;
		//two->setMyNum(num); used for single pointer.
		two[i].setMyNum(num);
	}

	cout << "The entered numbers for MyNum objects are." << endl;
	for (int i = 0; i < size; i++)
	{
		cout << "Number # " << i << " is: " << two[i].getMyNum() << endl;;;
	}

	int temp = 0;
	for (int i = 0; i < size - 1; i++)
	{
		for (int j = i+1; j < size; j++)
		{
			if (two[i].getMyNum() > two[j].getMyNum())
			{
				temp = two[i].getMyNum();
				two[i].setMyNum(two[j].getMyNum());
				two[j].setMyNum(temp);
			}
		}
	}

	cout << "Sorted MyNum objects are." << endl;
	for (int i = 0; i < size; i++)
	{
		cout << two[i].getMyNum() << endl;
	}
	

	return 0;
}