#include"Name.h"
#include"helperFunctions.h"

int nameCompare(Name name1, Name name2)
{

	char* firstn1 = name1.getFirstname();
	char* firstn2 = name2.getFirstname();
	char* lastn1 = name1.getlastname();
	char* lastn2 = name2.getlastname();
	int lenfn1 = strLength(firstn1);
	int lenfn2 = strLength(firstn2);
	int lenln1 = strLength(lastn1);
	int lenln2 = strLength(lastn2);
	if (lenfn1 != lenfn2)
	{
		for (int i = 0; firstn1[i] != '\0' && firstn2[i] != '\0'; i++)
		{
			if (firstn1[i] > firstn2[i])
			{
				return 1;
			}
			else if (firstn1[i] < firstn2[i])
			{
				return -1;
			}
		}
	}
	else if (lenfn1 == lenfn2)
	{
		for (int i = 0; firstn1[i] != '\0' && firstn2[i] != '\0'; i++)
		{
			if (firstn1[i] > firstn2[i])
			{
				return 1;
			}
			else if (firstn1[i] < firstn2[i])
			{
				return -1;
			}
		}
	}
	if (lenln1 != lenln2)
	{
		for (int i = 0; lastn1[i] != '\0' && lastn2[i] != '\0'; i++)
		{
			if (lastn1[i] > lastn2[i])
			{
				return 1;
			}
			else if (lastn1[i] < lastn2[i])
			{
				return -1;
			}
		}
	}
	else if (lenln1 == lenln2)
	{
		for (int i = 0; lastn1[i] != '\0' && lastn2[i] != '\0'; i++)
		{
			if (lastn1[i] > lastn2[i])
			{
				return 1;
			}
			else if (lastn1[i] < lastn2[i])
			{
				return -1;
			}
		}
	}
	delete[]firstn1;
	delete[]firstn2;
	delete[]lastn1;
	delete[]lastn2;
	firstn1 = nullptr;
	lastn1 = nullptr;
	firstn2 = nullptr;
	lastn2 = nullptr;

	return 0;
}

void fun(Name obj)
{
	//obj.camelCase();
	cout << "CamelCase()" << endl;
	obj.display();
	//cout<< obj.fullName();
	
}
char* in()
{
	char a[20] = { "\0" };
	cin.getline(a, 20);
	return a;
}
int main()
{
	int n = 0;
	bool flag = true;
	char fn[20] = { "\0" };
	char ln[20] = { "\0" };
	cout << "The checks of All the Functions will be done on the Name You will enter Following : " << endl;
	cout << "Enter First name : ";
	cin.getline(fn, 20);
	cout << "Enter Last name : ";
	cin.getline(ln, 20);
	Name n1(fn,ln);
	n1.display();
	cout << "Name length = " << n1.nameLength()<<endl;
	cout << "Please Enter How Many names you want To Enter : ";
	cin >> n;
	
	Name* n2 = new Name[n];
	cin.ignore();
	for (int i = 0; i < n; i++)
	{
		cout << "Enter First Name of obj " << i + 1 << " : ";
		n2[i].setFirstname(in());
		cout << "Enter Last Name of obj " << i + 1 << " : ";
		n2[i].setLastname(in());
	}
	for (int i = 0; i < n; i++)
	{
		n2[i].display();
		cout << "Name length = " << n2[i].nameLength()<<endl;

	}
	Name n3;
	n1.copyName(n3);
	cout << endl << endl;
	cout << "Name : "; n1.display();
	cout << "copyName()" << endl;
	cout << "copyName() in another object n3 : "; n3.display();
	cout << endl << endl;
	n1.display();
	flag = n1.isValidName();
	cout << endl << endl;
	cout << "Isvalid()" << endl;
	if (flag == true)
	{
		cout << "Name is valid : "; n1.display();
		
	}
	else if(flag==false)
	{
		cout << "Name is not valid : "; n1.display();
	}
	cout << endl << endl;
	cout << "fullname()" << endl;
	cout << n1.fullName() << endl;
	cout << endl << endl;
	n1.camelCase();
	cout << "Camel case()" << endl;
	n1.display();
	cout << endl << endl;
	n1.toLower();
	cout << "lower case()" << endl;
	n1.display();
	cout << endl << endl;
	n1.toUpper();
	cout << "upper case()" << endl;
	cout << endl << endl;
	n1.swapNames();
	cout << "swapNames()" << endl;
	n1.display();
	cout << endl << endl << "Same Name give 0 output Unequal returns -1 or 1" << endl << endl;
	cout << "Comparison between ";//comparing two names
	n1.display();
	cout << "  And  ";
	n2[0].display();
	cout<< nameCompare(n1, n2[0]) << endl;
	cout << "Comparison between ";//comparing two names
	n1.display();
	cout << "  And  ";
	n1.display();
	cout << nameCompare(n1, n1) << endl;
	delete[]n2;
	n2 = nullptr;
	return 0;
}