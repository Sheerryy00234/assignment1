#pragma once
#include<iostream>
using namespace std;

class MyNum
{
private:
	int num;

public:
	//parameterized constructor
	MyNum(int n = 0);

	//setters
	void setMyNum(int n);

	//getters
	int getMyNum();

	//My Fuctions
	int positive(int n);
	int negative(int n);
};

