#include "Name.h"
#include"helperFunctions.h"

Name::Name()
{
	firstName = nullptr;
	lastName = nullptr;
}
Name::Name(char* first=nullptr , char* last=nullptr)//parametrized constructor
{
	int length = 0;
	while (true)
	{
		if (first[length] == '\0')
			break;
		else
			length++;
	}

	firstName = new char[length + 1];

	for (int i = 0; i < length; i++)
		firstName[i] = first[i];

	firstName[length] = '\0';


	length = 0;
	while (true)
	{
		if (last[length] == '\0')
			break;
		else
			length++;
	}

	lastName = new char[length + 1];

	for (int i = 0; i < length; i++)
		lastName[i] = last[i];

	lastName[length] = '\0';
}

void Name::camelCase()//first letter capital
{
	if (firstName[0] <= 'z' && firstName[0] >= 'a')
	{
		firstName[0] = firstName[0] - 32;
	}
	if (lastName[0] <= 'z' && lastName[0] >= 'a')
	{
		lastName[0] = lastName[0] - 32;
	}
}

void Name::toLower()//To convert Lower case
{
	int flength = strLength(firstName);
	int lalength = strLength(lastName);
	for (int i = 0; i < flength; i++)
	{
		if (firstName[i] <= 'Z' && firstName[i] >= 'A')
		{
			firstName[i] = firstName[i] + 32;
		}
	}
	for (int i = 0; i < lalength; i++)
	{
		if (lastName[i] <= 'Z' && lastName[i] >= 'A')
		{
			lastName[i] = lastName[i] + 32;
		}
	}
}

void Name::toUpper()//To convert Upper case
{
	int flength = strLength(firstName);
	int lalength = strLength(lastName);
	for (int i = 0; i < flength; i++)
	{
		if (firstName[i] <= 'z' && firstName[i] >= 'a')
		{
			firstName[i] = firstName[i] - 32;
		}
	}
	for (int i = 0; i < lalength; i++)
	{
		if (lastName[i] <= 'z' && lastName[i] >= 'a')
		{
			lastName[i] = lastName[i] - 32;
		}
	}
}

int Name::nameLength()//returns the total length of Name
{
	return strLength(firstName) + strLength(lastName);
}


void Name::swapNames()//Swap names by shallow copy 
{
	int flength = strLength(firstName);
	int lalength = strLength(lastName);
	char* temp=nullptr;
	
	temp = new char[flength + 1];
	for (int i = 0; i < flength; i++)
		temp[i] = firstName[i];
	temp[flength] = '\0';

	firstName = nullptr;
	firstName = new char[flength + 1];
	for (int i = 0; i < flength; i++)
		firstName[i] = lastName[i];
	firstName[flength] = '\0';

	lastName = nullptr;
	lastName = new char[flength + 1];
	for (int i = 0; i < flength; i++)
		lastName[i] = temp[i];
	lastName[flength] = '\0';
	delete[]temp;
	temp = nullptr;
}

void Name::display()//simple display function
{
	cout << firstName << " " << lastName << endl;
}


char* Name::fullName()//to return a Full name as a pointer
{
	int fl= strLength(firstName) ;
	int lsl = strLength(lastName);
	int count = 0;
	char* fulln = new char[fl+lsl+2];
	for (int i = 0; i < fl; i++)
	{
		fulln[count] = firstName[i];
		count++;
	}
	fulln[count] = ' ';
	count++;
	for (int i = 0; i < lsl; i++)
	{
		fulln[count] = lastName[i];
		count++;
	}
	fulln[fl + lsl + 1] = '\0';
	return fulln;
}

bool Name::isValidName()//To check if there is special char or not
{
	int fl = strLength(firstName);
	int lsl = strLength(lastName);
	for (int i = 0; i < fl+1; i++)
	{
		if (firstName[i] >= '!' && firstName[i] <= '@' || firstName[i] >= '[' && firstName[i] <= '`' || firstName[i] >= '{' && firstName[i] <= '~')
		{
			
			return false;
		}
	}
	for (int i = 0; i < lsl+1; i++)
	{
		if (lastName[i] >= '!' && lastName[i] <= '@'  || lastName[i] >= '[' && lastName[i] <= '`' || lastName[i] >= '{' && lastName[i] <= '~')
		{
			
			return false;
		}
	}
	return true;
}

Name::Name(const Name& otherObj)//Copy constructor
{
	int length = 0;
	while (true)
	{
		if (otherObj.firstName[length] == '\0')
			break;
		else
			length++;
	}

	firstName = new char[length + 1];

	for (int i = 0; i < length; i++)
	{
		firstName[i] = otherObj.firstName[i];
	}
	firstName[length] = '\0';
	
	length = 0;
	while (true)
	{
		if (otherObj.lastName[length] == '\0')
			break;
		else
			length++;
	}

	lastName = new char[length + 1];

	for (int i = 0; i < length; i++)
	{
		lastName[i] = otherObj.lastName[i];
	}
	lastName[length] = '\0';
	
}

void Name::copyName(Name& otherObj)
{
	int flength = strLength(firstName);
	int lalength = strLength(lastName);
	otherObj.firstName= new char[flength + 1];
	for (int i = 0; i < flength; i++)
		otherObj.firstName[i] = firstName[i];

	otherObj.firstName[flength] = '\0';
    otherObj.lastName = new char[lalength + 1];

	for (int i = 0; i < lalength; i++)
		otherObj.lastName[i] = lastName[i];

	otherObj.lastName[lalength] = '\0';
}

char* Name::getFirstname()//first name getter
{
	int length = 0;
	while (true)
	{
		if (firstName[length] == '\0')
			break;
		else
			length++;
	}

	char* temp = new char[length + 1];

	for (int i = 0; i < length; i++)
		temp[i] = firstName[i];

	temp[length] = '\0';

	return temp;
}

char* Name::getlastname()//LAts name getter
{
	int length = 0;
	while (true)
	{
		if (lastName[length] == '\0')
			break;
		else
			length++;
	}

	char* temp = new char[length + 1];

	for (int i = 0; i < length; i++)
		temp[i] = lastName[i];

	temp[length] = '\0';

	return temp;
}

void Name::setFirstname(char* n)
{
	int length = 0;
	while (true)
	{
		if (n[length] == '\0')
			break;
		else
			length++;
	}

	firstName = new char[length + 1];

	for (int i = 0; i < length; i++)
		firstName[i] = n[i];

	firstName[length] = '\0';
}

void Name::setLastname(char* n)
{
	int length = 0;
	while (true)
	{
		if (n[length] == '\0')
			break;
		else
			length++;
	}

	lastName = new char[length + 1];

	for (int i = 0; i < length; i++)
		lastName[i] = n[i];

	lastName[length] = '\0';
}

Name::~Name()//Destructor
{
	cout << "~Name is called" << endl;
	if (firstName != nullptr)
	{
		delete[]firstName;
		firstName = nullptr;
	}
	if (lastName != nullptr)
	{
		delete[]lastName;
		lastName = nullptr;
	}
}