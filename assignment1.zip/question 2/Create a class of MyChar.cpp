/*
Define a class MyChar having the following private attributes.
� A single char variable.
Now do the following operations on above mentioned class MyChar:
� Write parameterized constructor with default arguments.
� Write separate setters for each attribute to set value.
� Write separate getters for each attribute to get value.
� A function that can convert the number stored in MyChar into upperCase.
� A function that can convert the number stored in MyNum into lowerCase.
Now write a driver program (main()) to test the following functionalities on
MyChar class on your own.
1. Make a single MyChar object by taking data from user.
2. Print a single MyChar object data on screen.
2. Make N MyChar objects by taking data from the user, where N is asked from the user.
5. Print N MyChar objects data on screen.
6. Sort the N MyChar objects by ascii.
7. Print the Sorted MyChar objects on screen.
*/
#include"MyChar.h"
int main()
{
	MyChar one;
	char ch = 0;
	int num = 0;

	//cout << "Enter a character: "; cin >> ch;

	one.setMyChar(ch);

	//cout << one.getMyChar();

	cout << "How many objects do you want to create: " << endl;
	cout << "Enter here: "; cin >> num;

	MyChar *two;
	two = new MyChar[num];

	cout << "Enter data for created objects." << endl;
	for (int i = 0; i < num; i++)
	{
		cout << "Enter character for object # " << i << ": "; cin >> ch;
		two[i].setMyChar(ch);
	}

	cout << "Entered objects are: " << endl;
	for (int i = 0; i < num; i++)
	{
		cout << two[i].getMyChar() << endl;
	}

	char temp = 0;
	for (int i = 0; i < num - 1; i++)
	{
		for (int j = i + 1; j < num; j++)
		{
			if (two[i].getMyChar() > two[j].getMyChar())
			{
				temp = two[i].getMyChar();
				two[i].setMyChar(two[j].getMyChar());
				two[j].setMyChar(temp);
			}
		}
	}

	cout << "Sorted objects are." << endl;
	for (int i = 0; i < num; i++)
	{
		cout << two[i].getMyChar() << endl;
	}

	return 0;
}