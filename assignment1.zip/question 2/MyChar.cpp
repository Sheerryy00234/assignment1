#include "MyChar.h"

//parameterized constructor
MyChar::MyChar(char c)
{
	ch = c;
}

//setters
void MyChar::setMyChar(char c)
{
	ch = c;
}

//getters
char MyChar   ::    getMyChar()
{
	return ch;
}

//MyFunctions
char MyChar::upper(char c)
{
	if (c >= 'a' && c <= 'z')
	{
		return c - 32;
	}
	else
		return c;
}
char MyChar::lower(char c)
{
	if (c >= 'A' && c <= 'Z')
	{
		return c;
	}
	else
		return c;
}